<br/>
<p align="center">
  <a href="https://github.com/Xvirus-Team/xvirus-tools">
    <img src="https://xvirus.lol/xicon.png" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">[API-Tool]- XVirus</h3>

  <p align="center">
    Xvirus-Tools is a discord API script that takes advantage of Discords WEAK API
    <br/>
    <br/>
    <a href="https://discord.gg/xvirustool">Discord</a>
    .
    <a href="https://xvirus.lol/showcase.mp4">Sowcase</a>
  </p>
</p>

<p align="center">
  <img alt="Downloads" src="https://img.shields.io/github/downloads/Xvirus-Team/xvirus-tools/total">
  <img alt="Contributors" src="https://img.shields.io/github/contributors/Xvirus-Team/xvirus-tools?color=dark-green">
  <img alt="Forks" src="https://img.shields.io/github/forks/Xvirus-Team/xvirus-tools?style=social">
  <img alt="Stargazers" src="https://img.shields.io/github/stars/Xvirus-Team/xvirus-tools?style=social">
  <img alt="Issues" src="https://img.shields.io/github/issues/Xvirus-Team/xvirus-tools">
  <img alt="License" src="https://img.shields.io/github/license/Xvirus-Team/xvirus-tools">
</p>

<p align="center">
  <a href="https://discord.gg/xvirustool">
    <img alt="Discord" src="https://img.shields.io/discord/1146496916419526727?label=&logo=discord&logoColor=ffffff&color=C50F1f&labelColor=C50F1f">
  </a>
  <a href="https://www.codefactor.io/repository/github/xvirus-team/xvirus-tools">
    <img src="https://www.codefactor.io/repository/github/xvirus-team/xvirus-tools/badge" alt="CodeFactor" />
  </a>
</p>

## About The Project

<p align="center">
  <img alt="preview" src="https://s.dexv.lol/xs1A27uTVyEQ/oFIEbaqHpu4e.png">
</p>

Xvirus is a Python based project that boldly exploits Discord's API, wearing the badge of "legal" and "TOS-friendly" or we like to say so. It's a tool designed for those who want to venture into Discord's API while staying undetected and secure, especially when paired with the use of residential proxies.

At its core, Xvirus serves as a means of unlocking the potential of Discord's API with a sense of daring, all while acknowledging the importance of privacy and anonymity. We know how vital it is to operate within the boundaries, or at least pretend to, which is why Xvirus plays nice with proxies, ensuring your actions within Discord's API remain as covert as a spy in the night.

Here are some key aspects of Xvirus:

1. **Advanced TLS Integration:** Xvirus utilizes tls_client to establish secure connections, because, you know, security is essential, even when you're being cheeky.

2. **Proxy Shenanigans:** When combined with proxies, Xvirus takes your privacy to another level, making it nearly impossible for anyone to trace your digital footsteps. Not that we're encouraging mischief, of course, wink wink.

3. **Diverse Module Set:** Xvirus features a range of modules, each designed to expand your capabilities within Discord's API while maintaining a low profile, or at least trying to.

4. **User Friendly Design:** We've gone out of our way to make Xvirus user friendly, because even rebels need an easy to use tool. It's all part of the disguise.

5. **Compliance and Ethics:** While we playfully push the boundaries, we always aim to remain within the limits set by Discord's guidelines, fostering responsible and ethical use. Or at least we pretend to.

6. **Regular Updates:** Here's the twist, the paid version of Xvirus gets the full royal treatment with regular updates, unlocking even more powerful features and capabilities. It's like the VIP experience for digital exploiters. But don't worry, we still do our best to update the free version, even if it's not quite as powerful. We like to spread the love, even to the rebels on a budget.

Xvirus isn't about grandiose claims of being a masterpiece, it's a simple tool designed to provide a secure and discreet gateway into Discord's API, all while "maintaining a facade of legality and TOS friendliness".

## Getting Started

Xvirus is conveniently pre configured, simplifying the setup process for users. All that's required is to install Python and execute a straightforward batch file. It's that easy to get started.

### Installation

 clone the repository: 
```shell
git clone --recursive https://github.com/Xvirus0/Xvirus-Tools.git
```
Then enter the directory:
```shell
cd Xvirus-Tools
```
Finally just run Setup.bat and wait for it to complete.

## Usage

Once Xvirus is fully installed, you're ready to dive in and have fun exploiting Discord's weak API. It's as straightforward as that.

Xvirus boasts a user friendly menu that's number based, making it simple to select your desired options. Additionally, it's a MUST to have multiple Discord tokens and optionally proxies (whether residential or not) for enhanced anonymity. With these tools at your disposal, enjoy your journey of raiding and exploiting Discord's API with confidence.

## Disclaimer

|Xvirus was made for Educational purposes|
|-------------------------------------------------|
This project was created only for good purposes and personal use.
By using Xvirus, you agree that you hold responsibility and accountability of any consequences caused by your actions.

## License

Distributed under the MIT License. See [LICENSE](https://github.com/Xvirus-Team/xvirus-tools/blob/main/LICENSE) for more information.

## Authors

* **DEXV** - *Shit head (retarded)* - [DEXV](https://dexv.lol) - *Fully Maintaining Xvirus*
* **AdminX** - *Just Another German Retard* - [AdminX](https://adminx.pro) - *Maintaining Xvirus As Side Project*